/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kelas3turunan;

/**
 *
 * @author iav
 */
public class PresenterClass {
    
//    public PresenterClass(String nik, String ttl, String jk, String alamat, String agama, String status_kawin, String pekerjaan, String kewarganegaraan) {
//        super(nik, ttl, jk, alamat, agama, status_kawin, pekerjaan, kewarganegaraan);
//    }
    
//    public void viewPresenterClass(){
//            System.err.println("nik : " + this.nik);
//            System.err.println("ttl : " + this.ttl);
//            System.err.println("jeniskelamin : " + this.jk);
//            System.err.println("alamat : " + this.alamat);
//            System.err.println("agama : " + this.agama);
//            System.err.println("status_kawin : " + this.status_kawin);
//            System.err.println("pekerjaan : " + this.pekerjaan);
//            System.err.println("kewarganegaraan : " + this.kewarganegaraan);
//    }
    
}
